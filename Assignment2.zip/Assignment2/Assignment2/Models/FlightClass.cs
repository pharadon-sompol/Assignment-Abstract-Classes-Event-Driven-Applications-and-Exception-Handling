﻿using System;

namespace Assignment2.Models
{
    public class FlightClass
    {
        private string _flightCode;
        private string _airline;
        private string _departure;
        private string _arrival;
        private string _dayOfWeek;
        private string _departureTime;
        private int _availableSeats;
        private double _ticketPrice;

        public string FlightCode
        {
            get { return _flightCode; }
            set { _flightCode = value; }
        }

        public string Airline
        {
            get { return _airline; }
            set { _airline = value; }
        }

        public string Departure
        {
            get { return _departure; }
            set { _departure = value; }
        }

        public string Arrival
        {
            get { return _arrival; }
            set { _arrival = value; }
        }

        public string DayOfWeek
        {
            get { return _dayOfWeek; }
            set { _dayOfWeek = value; }
        }

        public string DepartureTime
        {
            get { return _departureTime; }
            set { _departureTime = value; }
        }

        public int AvailableSeats
        {
            get { return _availableSeats; }
            set { _availableSeats = value; }
        }

        public double TicketPrice
        {
            get { return _ticketPrice; }
            set { _ticketPrice = value; }
        }

        public FlightClass() { }

        public FlightClass(string flightCode, string airline, string departure, string arrival, string dayOfWeek, string departureTime, int availableSeats, double ticketPrice)
        {
            this._flightCode = flightCode;
            this._airline = airline;
            this._departure = departure;
            this._arrival = arrival;
            this._dayOfWeek = dayOfWeek;
            this._departureTime = departureTime;
            this._availableSeats = availableSeats;
            this._ticketPrice = ticketPrice;
        }

        public bool ReserveSeat()
        {
            if (AvailableSeats > 0)
            {
                AvailableSeats -= 1;
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
