﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2.Models
{
    internal class ReservationClass : FlightClass
    {
        private string _reservationCode;
        private string _name;
        private string _citizenship;
        private EStatus _status;

        public enum EStatus
        {
            Active,
            Inactive
        }

        public string ReservationCode
        {
            get { return _reservationCode; }
            set { _reservationCode = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Citizenship
        {
            get { return _citizenship; }
            set { _citizenship = value; }
        }

        public EStatus Status
        {
            get { return _status; }
            set { _status = value; }
        }

        public ReservationClass() { }

        public ReservationClass(string flightCode, string airline, string departure, string arrival, string dayOfWeek, string departureTime, int availableSeats, double ticketPrice, string name, string citizenship, string reservationCode, EStatus status)
            : base(flightCode, airline, departure, arrival, dayOfWeek, departureTime, availableSeats, ticketPrice)
        {
            this._name = name;
            this._citizenship = citizenship;
            this._reservationCode = reservationCode;
            this._status = status;
        }

        public void Serialize(BinaryWriter writer)
        {
            writer.Write(ReservationCode);
            writer.Write(FlightCode);
            writer.Write(Airline);
            writer.Write(Departure);
            writer.Write(Arrival);
            writer.Write(DayOfWeek);
            writer.Write(DepartureTime);
            writer.Write(AvailableSeats);
            writer.Write(TicketPrice);
            writer.Write(Name);
            writer.Write(Citizenship);
            writer.Write((int)Status);
        }

        public static ReservationClass Deserialize(BinaryReader reader)
        {
            return new ReservationClass
            {
                ReservationCode = reader.ReadString(),
                FlightCode = reader.ReadString(),
                Airline = reader.ReadString(),
                Departure = reader.ReadString(),
                Arrival = reader.ReadString(),
                DayOfWeek = reader.ReadString(),
                DepartureTime = reader.ReadString(),
                AvailableSeats = reader.ReadInt32(),
                TicketPrice = reader.ReadDouble(),
                Name = reader.ReadString(),
                Citizenship = reader.ReadString(),
                Status = (EStatus)reader.ReadInt32()
            };
        }

        public static string GenerateReservationCode()
        {
            Random rnd = new Random();
            char l1 = (char)rnd.Next('A', 'Z' + 1);  

            int d1 = rnd.Next(0, 10);
            int d2 = rnd.Next(0, 10);
            int d3 = rnd.Next(0, 10);
            int d4 = rnd.Next(0, 10);

            string result = $"{l1}{d1}{d2}{d3}{d4}";

            return result;
        }
    }
}
