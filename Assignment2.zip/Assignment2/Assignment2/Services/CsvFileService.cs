﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Assignment2.Models;
using System.Resources;
using Assignment2.Properties;

namespace Assignment2.Services
{
    public class CsvFileService
    {
        public static List<FlightClass> ReadFlightsCsv()
        {
            List<FlightClass> flightList = new List<FlightClass>();

            try
            {
                string[] lines = Data.flights.Split('\n'); 

                foreach (string line in lines)
                {
                    string[] values = line.Split(',');

                    string flightCode = values[0];
                    string airline = values[1];
                    string departure = values[2];
                    string arrival = values[3];
                    string dayOfWeek = values[4];
                    string departureTime = values[5];
                    int availableSeats = int.Parse(values[6]);
                    double ticketPrice = double.Parse(values[7]);

                    FlightClass flightObj = new FlightClass(
                        flightCode, airline, departure, arrival, dayOfWeek, departureTime, availableSeats, ticketPrice
                    );

                    flightList.Add(flightObj);
                }
                Console.WriteLine("CsvFileService: objects created successfully");
            }
            catch (FormatException fe)
            {
                Console.WriteLine($"Format value error in line. {fe.Message}.");
            }
            catch (FileNotFoundException fnf)
            {
                Console.WriteLine($"File Not Found! {fnf.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: \n{ex.Message}");
            }

            return flightList; 
        }
    }
}