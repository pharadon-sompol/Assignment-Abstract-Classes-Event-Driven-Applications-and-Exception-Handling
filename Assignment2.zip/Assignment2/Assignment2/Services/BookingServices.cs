﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment2.Models;

namespace Assignment2.Services
{
    internal class BookingService
    {
        private List<ReservationClass> bookingList = new List<ReservationClass>();

        public List<ReservationClass> BookingList
        {
            get { return bookingList; }
            set { bookingList = value; }
        }

        public BookingService() { }

        public List<ReservationClass> GetBookings()
        {
            if (FileIOService.LoadFile() != null)
            {
                bookingList = FileIOService.LoadFile();
            }

            return bookingList; 
        }

        public void AddBooking(ReservationClass newBooking)
        {
            bookingList.Add(newBooking);

            FileIOService.SaveToFile(bookingList); 
        }

        public void ModifyBooking(ReservationClass selectedBooking)
        {
            foreach (ReservationClass booking in bookingList)
            {
                if (booking.ReservationCode == selectedBooking.ReservationCode)
                {
                    booking.Name = selectedBooking.Name;
                    booking.Citizenship = selectedBooking.Citizenship;
                    booking.Status = selectedBooking.Status;

                    FileIOService.SaveToFile(bookingList);

                    break;
                }
            }
        }
    }
}
