﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Assignment2.Models;

namespace Assignment2.Services
{
    internal class FileIOService
    {
        private static string filePath = @"C:\cprg211\reservdb.bin";

        public static void SaveToFile(List<ReservationClass> bookingList)
        {
            try
            {
                using (FileStream fs = new FileStream(filePath, FileMode.Create, FileAccess.Write))
                using (BinaryWriter writer = new BinaryWriter(fs))
                {
                    foreach (ReservationClass booking in bookingList)
                    {
                        booking.Serialize(writer);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving to file: {ex.Message}");
                throw;
            }
        }

        public static List<ReservationClass> LoadFile()
        {
            List<ReservationClass> bookingList = new List<ReservationClass>();

            if (!File.Exists(filePath))
            {
                return bookingList;
            }

            try
            {
                using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                using (BinaryReader reader = new BinaryReader(fs))
                {
                    while (fs.Position < fs.Length)
                    {
                        ReservationClass booking = ReservationClass.Deserialize(reader);
                        bookingList.Add(booking);
                    }

                    return bookingList;
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine($"Error loading from file: {ex.Message}");
                throw;
            }
        }
    }
}
